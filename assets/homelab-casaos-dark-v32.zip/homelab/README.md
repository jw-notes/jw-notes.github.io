# Homelab

Themes, configs, tools and notes from my self-hosted homelab.

Made by [jw-notes](https://github.com/jw-notes).

## Themes

- [HomeServer for CasaOS](themes/casaos/dark/README.md): grey/glass UI with teal accents, dark/light controls and themed panels.
